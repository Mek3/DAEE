﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace MonitorSistemaWPF
{
    class ComandoReset : ICommand
    {
        RecursosSistema destinatario;

        public event EventHandler CanExecuteChanged;

        public ComandoReset(RecursosSistema r) 
        {
            this.destinatario = r;

        }
        public bool CanExecute(object parameter) 
        {
            return true;
        }
        public void Execute(object parameter) 
        {
            destinatario.MemoriaFisicaPorcentajeMaximo.Valor = 0;
            destinatario.MemoriaVirtualPorcentajeMaximo.Valor = 0;
            destinatario.DiscoEscritura.Valor = 0;
            destinatario.DiscoLectura.Valor= 0;
            destinatario.DiscoLecturaEscritura.Valor= 0;
            destinatario.MemoriaFisicaDisponible.Valor= 0;
            destinatario.MemoriaFisicaOcupada.Valor= 0;
            destinatario.MemoriaFisicaPorcentaje.Valor= 0;
            destinatario.MemoriaVirtualPorcentaje.Valor= 0;
            destinatario.RedPaquetesEntrada.Valor= 0;
            destinatario.RedPaquetesSalida.Valor= 0;
            destinatario.RedPaquetesEntradaSalida.Valor= 0;

        }
    }
}
