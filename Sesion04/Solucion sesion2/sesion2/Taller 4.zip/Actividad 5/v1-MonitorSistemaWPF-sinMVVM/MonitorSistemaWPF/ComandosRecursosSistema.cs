﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace MonitorSistemaWPF
{
    internal abstract class ComandosRecursosSistema: ICommand
    {
        protected RecursosSistema destinatario;

        public event EventHandler CanExecuteChanged;

        public ComandosRecursosSistema(RecursosSistema destinatario)
        {
            this.destinatario = destinatario;

        }
        public void NotifyCanExecuteChanged() {
            if (CanExecuteChanged != null) 
            {
                CanExecuteChanged(this, EventArgs.Empty);
            }
        }

        public abstract bool CanExecute(object parameter);
        public abstract void Execute(object parameter);
    }

    internal class ComandoReset : ComandosRecursosSistema
    {

        public ComandoReset(RecursosSistema r) : base(r)
        {

        }
        public override bool CanExecute(object parameter)
        {
            return true;
        }
        public override void Execute(object parameter)
        {
            destinatario.MemoriaFisicaPorcentajeMaximo.Valor = 0;
            destinatario.MemoriaVirtualPorcentajeMaximo.Valor = 0;
            destinatario.DiscoEscritura.Valor = 0;
            destinatario.DiscoLectura.Valor = 0;
            destinatario.DiscoLecturaEscritura.Valor = 0;
            destinatario.MemoriaFisicaDisponible.Valor = 0;
            destinatario.MemoriaFisicaOcupada.Valor = 0;
            destinatario.MemoriaFisicaPorcentaje.Valor = 0;
            destinatario.MemoriaVirtualPorcentaje.Valor = 0;
            destinatario.RedPaquetesEntrada.Valor = 0;
            destinatario.RedPaquetesSalida.Valor = 0;
            destinatario.RedPaquetesEntradaSalida.Valor = 0;

        }
    }

    internal class ComandoIniciar : ComandosRecursosSistema
    {
        public ComandoIniciar(RecursosSistema r) : base(r) 
        { 
        }

        public override bool CanExecute(object parameter)
        {
            return !destinatario.ejecutandose();
        }
        public override void Execute(object parameter)
        {
            destinatario.iniciar();
        }
    }

    internal class ComandoParar : ComandosRecursosSistema
    {
        public ComandoParar(RecursosSistema r) : base(r)
        {
        }

        public override bool CanExecute(object parameter)
        {
            return destinatario.ejecutandose();
        }
        public override void Execute(object parameter)
        {
            destinatario.parar();
        }
    }
}
