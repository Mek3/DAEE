﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonitorSistemaWPF
{
   public  class Medida : INotifyPropertyChanged
    {
        string titulo;
        double valor, maxValor;

        public Medida(string titulo)
        {
            this.Titulo = titulo;
        }

        public string Titulo { get => titulo; set => titulo = value; }
        public double Valor {
            get => valor;
            set 
            {
                valor = value;
                OnPropertyChanged("Valor");
            }
        }

        public double MaxValor
        {
            get => maxValor;
            set
            {
                maxValor = value;
                OnPropertyChanged("MaxValor");
            }
        }

        private void OnPropertyChanged(string v)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(v));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public override string ToString()
        {
            return String.Format("{0, 18:00000000.000}", Valor, MaxValor);
        }

    }
}
