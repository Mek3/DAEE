﻿using MonitorSistema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static MonitorSistema.LectorRecursosSistema;

namespace MonitorSistemaWPF
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        LectorRecursosSistema lectorRecursosSistema = new LectorRecursosSistema();
        System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
       

        public MainWindow()
        {
            Config.GetInstance().Load();
            cambiaIdioma();

            InitializeComponent();
           
            cambiaColores();
            cambiaPosicion();

            dispatcherTimer.Tick += new EventHandler(manejadorDispatcherTimer);         
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (dispatcherTimer.IsEnabled)
            {
                dispatcherTimer.Stop();
                btnActualizar.Content = Properties.Resources.iniciar;
            }
            else
            {
                dispatcherTimer.Interval = new TimeSpan(0, 0, 1); // se actualiza cada segundo
                dispatcherTimer.Start();
                btnActualizar.Content = Properties.Resources.parar;
            }

        }

        private void actualizaValores()
        {
            this.labelCPU.Content = lectorRecursosSistema.getCPU();
            this.labelDiscoLectura.Content = lectorRecursosSistema.getDatosDisco(DiskData.Read).ToString();
            this.labelDiscoEscritura.Content = lectorRecursosSistema.getDatosDisco(DiskData.Write).ToString();
            this.labelDiscoLecturaEscritura.Content = lectorRecursosSistema.getDatosDisco(DiskData.ReadAndWrite).ToString();
            this.labelRedRecibidos.Content = lectorRecursosSistema.getDatosRed(NetData.Received).ToString(); ;
            this.labelRedEnviados.Content = lectorRecursosSistema.getDatosRed(NetData.Sent).ToString(); ;
            this.labelRedRecibidosEnviados.Content = lectorRecursosSistema.getDatosRed(NetData.ReceivedAndSent).ToString();
            this.labelDiscosLogicos.Content = lectorRecursosSistema.getDiscosLogicos();
            this.labelMemoriaFisica.Content = lectorRecursosSistema.getMemoriaFisica();
            this.labelMemoriaVirtual.Content = lectorRecursosSistema.getMemoriaVirtual();
            this.labelOrdenadorFabricante.Content = lectorRecursosSistema.getOrdenadorFabricante();
            this.labelOrdenadorModelo.Content = lectorRecursosSistema.getOrdenadorModelo();
            this.labelOrdenadorProcesador.Content = lectorRecursosSistema.getProcesadores()[0];
            this.labelUsuario.Content = lectorRecursosSistema.getUsuario();
        }

        private void manejadorDispatcherTimer(object sender, EventArgs e)
        {
            actualizaValores();
        }

        private void btnPersonalizar_Click(object sender, RoutedEventArgs e) 
        {
            var dlg = new WindowConfig();
            dlg.ShowDialog();
            
            cambiaColores();
            cambiaIdioma();
            cambiaPosicion();
        }

        public void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void cambiaColores() 
        {
            var color = Config.GetInstance().color;
            if (color != null) 
            {
                var bgColor = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Config.GetInstance().color));
                labelOrdenador.Background = bgColor;
                labelMemoria.Background = bgColor;
                labelDisco.Background = bgColor;
                labelRed.Background = bgColor;
            }
        }
        private void cambiaIdioma() 
        {
            var lang = Config.GetInstance().lang;
            if (lang != null) 
            {
                System.Threading.Thread.CurrentThread.CurrentCulture =
                                new System.Globalization.CultureInfo(lang);
                System.Threading.Thread.CurrentThread.CurrentUICulture =
                System.Threading.Thread.CurrentThread.CurrentCulture;
            }
           
        }
        private void cambiaPosicion()
        {
            var pos = Config.GetInstance().pos;
            if (pos != null)
            {
                if (Config.GetInstance().pos.Equals("Derecha"))
                {
                    this.Left = SystemParameters.PrimaryScreenWidth - this.Width + 20; // derecha
                }
                else if (Config.GetInstance().pos.Equals("Centro"))
                {
                    this.Left = SystemParameters.PrimaryScreenWidth - (this.Width * 2); // centro
                }
                else if (Config.GetInstance().pos.Equals("Izquierda"))
                {
                    this.Left = SystemParameters.PrimaryScreenWidth - (this.Width * 3) + 200; // izquierda
                }
            }
        }
    }
}
