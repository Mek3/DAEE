using NUnit.Framework;

namespace TestMonitorSistema
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestConfig()
        {
            MonitorSistemaWPF.Config.GetInstance().Load();
            string originalLang = MonitorSistemaWPF.Config.GetInstance().lang;
            string originalColor = MonitorSistemaWPF.Config.GetInstance().color;

            MonitorSistemaWPF.Config.GetInstance().InitDefaults();

            const string testLang = "_testlang_";
            const string testColor = "_testcolor_";

            MonitorSistemaWPF.Config.GetInstance().color = testColor;
            MonitorSistemaWPF.Config.GetInstance().lang = testLang;
            MonitorSistemaWPF.Config.GetInstance().save();

            MonitorSistemaWPF.Config.GetInstance().InitDefaults();
            MonitorSistemaWPF.Config.GetInstance().Load();

            Assert.AreEqual(testLang, MonitorSistemaWPF.Config.GetInstance().lang);
            Assert.AreEqual(testColor, MonitorSistemaWPF.Config.GetInstance().color);

            if (originalColor != null || originalLang != null)
            {
                MonitorSistemaWPF.Config.GetInstance().lang = originalLang;
                MonitorSistemaWPF.Config.GetInstance().color = originalColor;
            }
        }
    }
}