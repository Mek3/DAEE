﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace taller7
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Taller7Entities db; 

        public MainWindow()
        {
            InitializeComponent();
            db = new Taller7Entities();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            System.Windows.Data.CollectionViewSource productoViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("productoViewSource")));
            // Cargar datos estableciendo la propiedad CollectionViewSource.Source:
            // productoViewSource.Source = [origen de datos genérico]
            db.Productos.Load();
            productoViewSource.Source = db.Productos.Local;

        }

        public void btnDetail_Click(object sender, EventArgs e)
        {
            Producto p = (Producto)gridListado.SelectedItem;
            lblTituloDetalle.Content = "Detalle del producto: '" +
            p.Nombre + "'";
            gridListado.Visibility = Visibility.Hidden;
            gridCajaDetalle.Margin = new Thickness(5, 55, 5, 4);
            gridCajaDetalle.Visibility = Visibility.Visible;
        }
        private void btnVolverDetalle_Click(object sender, RoutedEventArgs e)
        {
            gridCajaDetalle.Margin = new Thickness(825, 55, -650, 5);
            gridCajaDetalle.Visibility = Visibility.Hidden;
            gridListado.Visibility = Visibility.Visible;
        }

        private void btnNuevo_Click(object sender, RoutedEventArgs e)
        {
            gridListado.Visibility = Visibility.Hidden;
            btnNuevo.Visibility = Visibility.Hidden;
            gridCajaNuevo.Margin = new Thickness(5, 55, 5, 4);
            gridCajaNuevo.Visibility = Visibility.Visible;
        }
        private void btnVolverNuevo_Click(object sender, RoutedEventArgs
        e)
        {
            gridCajaNuevo.Margin = new Thickness(5, -393, 3.6, 453);
            gridCajaNuevo.Visibility = Visibility.Hidden;
            gridListado.Visibility = Visibility.Visible;
            btnNuevo.Visibility = Visibility.Visible;
        }
    }
}
